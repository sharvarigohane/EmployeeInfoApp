import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { 
  Monitor, 
  Database, 
  Shield, 
  MessageSquare, 
  Calendar, 
  FileText, 
  Code, 
  Users,
  Mail,
  BarChart3 
} from "lucide-react";

// Mock tools data
const toolsData = [
  {
    name: "Slack",
    description: "Team communication and collaboration platform",
    responsiblePerson: "IT Support Team",
    category: "Communication",
    icon: MessageSquare,
    status: "Active",
    users: 150
  },
  {
    name: "Jira",
    description: "Project management and issue tracking",
    responsiblePerson: "David Chen",
    category: "Development",
    icon: Code,
    status: "Active",
    users: 45
  },
  {
    name: "Google Workspace",
    description: "Email, documents, and productivity suite",
    responsiblePerson: "IT Support Team",
    category: "Productivity",
    icon: Mail,
    status: "Active",
    users: 150
  },
  {
    name: "Figma",
    description: "Design and prototyping tool",
    responsiblePerson: "Mike Johnson",
    category: "Design",
    icon: Monitor,
    status: "Active",
    users: 12
  },
  {
    name: "Database Console",
    description: "Internal database management system",
    responsiblePerson: "Lisa Wang",
    category: "Infrastructure",
    icon: Database,
    status: "Active",
    users: 8
  },
  {
    name: "VPN Access",
    description: "Secure remote access to company resources",
    responsiblePerson: "Security Team",
    category: "Security",
    icon: Shield,
    status: "Active",
    users: 89
  },
  {
    name: "Calendly",
    description: "Meeting scheduling and calendar management",
    responsiblePerson: "Jane Smith",
    category: "Productivity",
    icon: Calendar,
    status: "Active",
    users: 67
  },
  {
    name: "Notion",
    description: "Documentation and knowledge base",
    responsiblePerson: "Emily Rodriguez",
    category: "Documentation",
    icon: FileText,
    status: "Active",
    users: 98
  },
  {
    name: "Zoom",
    description: "Video conferencing and meetings",
    responsiblePerson: "IT Support Team",
    category: "Communication",
    icon: Users,
    status: "Active",
    users: 150
  },
  {
    name: "Analytics Dashboard",
    description: "Business intelligence and reporting",
    responsiblePerson: "Data Team",
    category: "Analytics",
    icon: BarChart3,
    status: "Active",
    users: 23
  }
];

const categoryColors = {
  Communication: "bg-blue-100 text-blue-800",
  Development: "bg-green-100 text-green-800",
  Productivity: "bg-purple-100 text-purple-800",
  Design: "bg-pink-100 text-pink-800",
  Infrastructure: "bg-orange-100 text-orange-800",
  Security: "bg-red-100 text-red-800",
  Documentation: "bg-yellow-100 text-yellow-800",
  Analytics: "bg-indigo-100 text-indigo-800"
};

export default function Tools() {
  const categories = [...new Set(toolsData.map(tool => tool.category))];
  
  return (
    <div className="max-w-7xl mx-auto p-6 space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-3xl font-medium">Tools</h1>
        <p className="text-muted-foreground">
          Company tools and systems with responsible personnel
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {toolsData.map((tool, index) => {
          const IconComponent = tool.icon;
          return (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <IconComponent className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{tool.name}</CardTitle>
                      <Badge 
                        variant="secondary" 
                        className={`text-xs mt-1 ${
                          categoryColors[tool.category as keyof typeof categoryColors] || 'bg-gray-100 text-gray-800'
                        }`}
                      >
                        {tool.category}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">{tool.description}</p>
                
                <div className="space-y-2">
                  <div>
                    <p className="font-medium text-sm">Responsible Person</p>
                    <p className="text-sm text-muted-foreground">{tool.responsiblePerson}</p>
                  </div>
                  
                  <div className="flex justify-between items-center pt-2">
                    <div>
                      <p className="font-medium text-sm">Status</p>
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-sm text-muted-foreground">{tool.status}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-sm">Users</p>
                      <p className="text-sm text-muted-foreground">{tool.users}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle className="text-center">Tools by Category</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {categories.map((category) => {
              const toolCount = toolsData.filter(tool => tool.category === category).length;
              return (
                <div key={category} className="text-center p-4 bg-muted rounded-lg">
                  <p className="text-lg font-medium">{toolCount}</p>
                  <p className="text-sm text-muted-foreground">{category}</p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}