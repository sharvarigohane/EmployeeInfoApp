import { Button } from "./ui/button";

interface NavigationProps {
  selectedOption: string;
  onOptionSelect: (option: string) => void;
}

export default function Navigation({ selectedOption, onOptionSelect }: NavigationProps) {
  const options = [
    { id: 'who-am-i', label: 'Who Am I?' },
    { id: 'what-am-i', label: 'What Am I?' },
    { id: 'tools', label: 'Tools' }
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-center space-x-1 py-4">
          {options.map((option) => (
            <Button
              key={option.id}
              variant={selectedOption === option.id ? "default" : "ghost"}
              onClick={() => onOptionSelect(option.id)}
              className="rounded-lg"
            >
              {option.label}
            </Button>
          ))}
        </div>
      </div>
    </nav>
  );
}