import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { 
  Monitor, 
  Database, 
  Shield, 
  MessageSquare, 
  Calendar, 
  FileText, 
  Code, 
  Users,
  Mail,
  BarChart3,
  Search,
  Filter,
  ExternalLink,
  UserPlus
} from "lucide-react";
import { toast } from "sonner@2.0.3";

// Mock tools data
const toolsData = [
  {
    name: "Slack",
    description: "Team communication and collaboration platform",
    responsiblePerson: "IT Support Team",
    category: "Communication",
    icon: MessageSquare,
    status: "Active",
    users: 150,
    url: "https://workspace.slack.com"
  },
  {
    name: "Jira",
    description: "Project management and issue tracking",
    responsiblePerson: "David Chen",
    category: "Development",
    icon: Code,
    status: "Active",
    users: 45,
    url: "https://company.atlassian.net"
  },
  {
    name: "Google Workspace",
    description: "Email, documents, and productivity suite",
    responsiblePerson: "IT Support Team",
    category: "Productivity",
    icon: Mail,
    status: "Active",
    users: 150,
    url: "https://workspace.google.com"
  },
  {
    name: "Figma",
    description: "Design and prototyping tool",
    responsiblePerson: "Mike Johnson",
    category: "Design",
    icon: Monitor,
    status: "Active",
    users: 12,
    url: "https://figma.com"
  },
  {
    name: "Database Console",
    description: "Internal database management system",
    responsiblePerson: "Lisa Wang",
    category: "Infrastructure",
    icon: Database,
    status: "Active",
    users: 8,
    url: "https://db.company.com"
  },
  {
    name: "VPN Access",
    description: "Secure remote access to company resources",
    responsiblePerson: "Security Team",
    category: "Security",
    icon: Shield,
    status: "Active",
    users: 89,
    url: "https://vpn.company.com"
  },
  {
    name: "Calendly",
    description: "Meeting scheduling and calendar management",
    responsiblePerson: "Jane Smith",
    category: "Productivity",
    icon: Calendar,
    status: "Active",
    users: 67,
    url: "https://calendly.com"
  },
  {
    name: "Notion",
    description: "Documentation and knowledge base",
    responsiblePerson: "Emily Rodriguez",
    category: "Documentation",
    icon: FileText,
    status: "Active",
    users: 98,
    url: "https://notion.so"
  },
  {
    name: "Zoom",
    description: "Video conferencing and meetings",
    responsiblePerson: "IT Support Team",
    category: "Communication",
    icon: Users,
    status: "Active",
    users: 150,
    url: "https://zoom.us"
  },
  {
    name: "Analytics Dashboard",
    description: "Business intelligence and reporting",
    responsiblePerson: "Data Team",
    category: "Analytics",
    icon: BarChart3,
    status: "Active",
    users: 23,
    url: "https://analytics.company.com"
  }
];

const categoryColors = {
  Communication: "bg-gradient-to-r from-blue-100 to-cyan-100 text-blue-800 hover:from-blue-200 hover:to-cyan-200 border-blue-300",
  Development: "bg-gradient-to-r from-green-100 to-emerald-100 text-green-800 hover:from-green-200 hover:to-emerald-200 border-green-300",
  Productivity: "bg-gradient-to-r from-purple-100 to-violet-100 text-purple-800 hover:from-purple-200 hover:to-violet-200 border-purple-300",
  Design: "bg-gradient-to-r from-pink-100 to-rose-100 text-pink-800 hover:from-pink-200 hover:to-rose-200 border-pink-300",
  Infrastructure: "bg-gradient-to-r from-orange-100 to-amber-100 text-orange-800 hover:from-orange-200 hover:to-amber-200 border-orange-300",
  Security: "bg-gradient-to-r from-red-100 to-pink-100 text-red-800 hover:from-red-200 hover:to-pink-200 border-red-300",
  Documentation: "bg-gradient-to-r from-yellow-100 to-orange-100 text-yellow-800 hover:from-yellow-200 hover:to-orange-200 border-yellow-300",
  Analytics: "bg-gradient-to-r from-indigo-100 to-purple-100 text-indigo-800 hover:from-indigo-200 hover:to-purple-200 border-indigo-300"
};

interface AccessRequestModalProps {
  tool: any;
  isOpen: boolean;
  onClose: () => void;
}

function AccessRequestModal({ tool, isOpen, onClose }: AccessRequestModalProps) {
  const [requestReason, setRequestReason] = useState("");
  const [userName, setUserName] = useState("");
  const [userEmail, setUserEmail] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (userName && userEmail && requestReason) {
      toast.success(`Access request for ${tool.name} submitted successfully! You will receive an email confirmation shortly.`);
      setRequestReason("");
      setUserName("");
      setUserEmail("");
      onClose();
    } else {
      toast.error("Please fill in all required fields.");
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <UserPlus className="h-5 w-5 text-blue-500" />
            <span>Request Access to {tool.name}</span>
          </DialogTitle>
          <DialogDescription>
            Fill out the form below to request access to {tool.name}. Your request will be reviewed by {tool.responsiblePerson}.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="userName">Full Name *</Label>
            <Input
              id="userName"
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
              placeholder="Enter your full name"
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="userEmail">Email Address *</Label>
            <Input
              id="userEmail"
              type="email"
              value={userEmail}
              onChange={(e) => setUserEmail(e.target.value)}
              placeholder="Enter your email address"
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="reason">Reason for Access *</Label>
            <Textarea
              id="reason"
              value={requestReason}
              onChange={(e) => setRequestReason(e.target.value)}
              placeholder="Please explain why you need access to this tool..."
              rows={4}
              required
            />
          </div>
          
          <div className="flex justify-end space-x-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button 
              type="submit"
              className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-purple-600 hover:to-indigo-600 text-white"
            >
              Submit Request
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function Tools() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTool, setSelectedTool] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const categories = [...new Set(toolsData.map(tool => tool.category))];
  
  const filteredTools = toolsData.filter(tool => {
    const matchesCategory = !selectedCategory || tool.category === selectedCategory;
    const matchesSearch = !searchTerm || 
      tool.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tool.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tool.responsiblePerson.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleRequestAccess = (tool: any) => {
    setSelectedTool(tool);
    setIsModalOpen(true);
  };

  const clearFilters = () => {
    setSelectedCategory(null);
    setSearchTerm("");
  };

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-8">
      <div className="text-center space-y-4 animate-in fade-in-50 slide-in-from-top duration-700">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent">Tools</h1>
        <p className="text-lg text-gray-600">
          Company tools and systems with responsible personnel
        </p>
      </div>

      {/* Filters and Search */}
      <Card className="animate-in fade-in-50 slide-in-from-top duration-500 bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200 shadow-xl">
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
            <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-4 flex-1">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-500 h-5 w-5" />
                <Input
                  type="text"
                  placeholder="Search tools..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-12 h-12 border-2 border-blue-200 focus:border-blue-500 rounded-xl bg-white/90 backdrop-blur-sm shadow-lg"
                />
              </div>
              
              <div className="flex flex-wrap gap-2">
                <Button
                  variant={selectedCategory === null ? "default" : "outline"}
                  onClick={() => setSelectedCategory(null)}
                  className={selectedCategory === null ? "bg-gradient-to-r from-blue-500 to-purple-600 text-white" : ""}
                >
                  All
                </Button>
                {categories.map((category) => (
                  <Button
                    key={category}
                    variant={selectedCategory === category ? "default" : "outline"}
                    onClick={() => setSelectedCategory(category)}
                    className={`text-xs ${selectedCategory === category ? "bg-gradient-to-r from-blue-500 to-purple-600 text-white" : ""}`}
                  >
                    {category}
                  </Button>
                ))}
              </div>
            </div>
            
            {(selectedCategory || searchTerm) && (
              <Button 
                variant="outline" 
                onClick={clearFilters}
                className="hover:scale-105 transition-all duration-200"
              >
                Clear Filters
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Tools Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTools.map((tool, index) => {
          const IconComponent = tool.icon;
          return (
            <Card 
              key={tool.name} 
              className="hover:shadow-xl hover:scale-105 transition-all duration-300 animate-in fade-in-50 slide-in-from-bottom bg-gradient-to-br from-white to-gray-50 border-gray-200 shadow-lg"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className="p-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl shadow-md">
                      <IconComponent className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-lg text-gray-800">{tool.name}</CardTitle>
                      <Badge 
                        variant="secondary" 
                        className={`text-xs mt-1 transition-all duration-200 cursor-pointer ${
                          categoryColors[tool.category as keyof typeof categoryColors] || 'bg-gray-100 text-gray-800'
                        }`}
                        onClick={() => setSelectedCategory(tool.category)}
                      >
                        {tool.category}
                      </Badge>
                    </div>
                  </div>
                  <a 
                    href={tool.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-gray-400 hover:text-blue-500 transition-colors"
                  >
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-600 leading-relaxed">{tool.description}</p>
                
                <div className="space-y-3">
                  <div className="p-3 rounded-xl bg-gradient-to-r from-blue-50 to-cyan-50 hover:from-blue-100 hover:to-cyan-100 transition-all duration-300">
                    <p className="font-medium text-sm text-gray-800">Responsible Person</p>
                    <p className="text-sm text-gray-600">{tool.responsiblePerson}</p>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div className="p-3 rounded-xl bg-gradient-to-r from-green-50 to-emerald-50 hover:from-green-100 hover:to-emerald-100 transition-all duration-300 flex-1 mr-2">
                      <p className="font-medium text-sm text-gray-800">Status</p>
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                        <span className="text-sm text-gray-600">{tool.status}</span>
                      </div>
                    </div>
                    <div className="p-3 rounded-xl bg-gradient-to-r from-purple-50 to-violet-50 hover:from-purple-100 hover:to-violet-100 transition-all duration-300 text-center flex-1 ml-2">
                      <p className="font-medium text-sm text-gray-800">Users</p>
                      <p className="text-sm text-gray-600">{tool.users}</p>
                    </div>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-gray-200">
                  <Button 
                    onClick={() => handleRequestAccess(tool)}
                    className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-purple-600 hover:to-indigo-600 text-white rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300"
                  >
                    <UserPlus className="h-4 w-4 mr-2" />
                    Request Access
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredTools.length === 0 && (
        <Card className="max-w-2xl mx-auto animate-in fade-in-50 duration-500 bg-gradient-to-br from-gray-50 to-gray-100 border-gray-200">
          <CardContent className="text-center py-8 space-y-4">
            <Filter className="h-12 w-12 text-gray-400 mx-auto" />
            <div>
              <p className="text-gray-600 mb-2">No tools found matching your criteria.</p>
              <Button 
                variant="outline"
                onClick={clearFilters}
                className="hover:scale-105 transition-all duration-200"
              >
                Clear Filters
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Summary Stats */}
      <Card className="max-w-4xl mx-auto animate-in fade-in-50 slide-in-from-bottom duration-700 delay-300 bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200 shadow-xl">
        <CardHeader>
          <CardTitle className="text-center text-2xl bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Tools Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-6 bg-gradient-to-r from-blue-100 to-cyan-100 rounded-xl hover:from-blue-200 hover:to-cyan-200 transition-all duration-300 cursor-pointer shadow-md">
              <p className="text-2xl font-bold text-blue-700">{filteredTools.length}</p>
              <p className="text-blue-600 text-sm">
                {selectedCategory ? `${selectedCategory} Tools` : 'Total Tools'}
              </p>
            </div>
            <div className="text-center p-6 bg-gradient-to-r from-green-100 to-emerald-100 rounded-xl hover:from-green-200 hover:to-emerald-200 transition-all duration-300 cursor-pointer shadow-md">
              <p className="text-2xl font-bold text-green-700">
                {filteredTools.reduce((sum, tool) => sum + tool.users, 0)}
              </p>
              <p className="text-green-600 text-sm">Total Users</p>
            </div>
            <div className="text-center p-6 bg-gradient-to-r from-purple-100 to-violet-100 rounded-xl hover:from-purple-200 hover:to-violet-200 transition-all duration-300 cursor-pointer shadow-md">
              <p className="text-2xl font-bold text-purple-700">
                {selectedCategory ? 1 : categories.length}
              </p>
              <p className="text-purple-600 text-sm">Categories</p>
            </div>
            <div className="text-center p-6 bg-gradient-to-r from-pink-100 to-rose-100 rounded-xl hover:from-pink-200 hover:to-rose-200 transition-all duration-300 cursor-pointer shadow-md">
              <p className="text-2xl font-bold text-pink-700">100%</p>
              <p className="text-pink-600 text-sm">Uptime</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Access Request Modal */}
      {selectedTool && (
        <AccessRequestModal 
          tool={selectedTool}
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
        />
      )}
    </div>
  );
}