import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Users, ArrowDown, ArrowRight } from "lucide-react";

// Mock organizational data
const orgData = {
  name: "Sarah Wilson",
  role: "Chief Executive Officer",
  children: [
    {
      name: "David Chen",
      role: "Chief Technology Officer",
      children: [
        {
          name: "John Doe",
          role: "Senior Software Engineer",
          children: [
            { name: "Alex Park", role: "Junior Developer" },
            { name: "Maria Garcia", role: "Frontend Developer" }
          ]
        },
        {
          name: "Lisa Wang",
          role: "DevOps Manager",
          children: [
            { name: "Tom Brown", role: "Site Reliability Engineer" },
            { name: "Ana Silva", role: "Cloud Architect" }
          ]
        }
      ]
    },
    {
      name: "Emily Rodriguez",
      role: "Chief Product Officer",
      children: [
        {
          name: "Jane Smith",
          role: "Product Manager",
          children: [
            { name: "Chris Lee", role: "Product Analyst" },
            { name: "Sam Johnson", role: "UX Researcher" }
          ]
        },
        {
          name: "Mike Johnson",
          role: "UX Designer",
          children: [
            { name: "Rachel Kim", role: "Visual Designer" },
            { name: "Kevin Zhang", role: "Interaction Designer" }
          ]
        }
      ]
    }
  ]
};

interface OrgNodeProps {
  person: any;
  level?: number;
}

function OrgNode({ person, level = 0 }: OrgNodeProps) {
  const hasChildren = person.children && person.children.length > 0;
  const isRoot = level === 0;
  
  return (
    <div className={`flex flex-col items-center ${level > 0 ? 'mt-6' : ''}`}>
      <Card className={`w-64 ${isRoot ? 'border-primary bg-primary/5' : ''}`}>
        <CardContent className="p-4 text-center">
          <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3 ${
            isRoot ? 'bg-primary text-primary-foreground' : 'bg-muted'
          }`}>
            <Users className="h-6 w-6" />
          </div>
          <h3 className="font-medium text-sm">{person.name}</h3>
          <p className="text-xs text-muted-foreground mt-1">{person.role}</p>
        </CardContent>
      </Card>
      
      {hasChildren && (
        <>
          <ArrowDown className="h-6 w-6 text-muted-foreground my-2" />
          <div className="flex flex-wrap justify-center gap-8">
            {person.children.map((child: any, index: number) => (
              <div key={index} className="flex flex-col items-center">
                <OrgNode person={child} level={level + 1} />
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default function WhatAmI() {
  return (
    <div className="max-w-7xl mx-auto p-6 space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-3xl font-medium">What Am I?</h1>
        <p className="text-muted-foreground">
          Organizational hierarchy and reporting structure
        </p>
      </div>

      <div className="overflow-x-auto">
        <div className="min-w-max flex justify-center">
          <OrgNode person={orgData} />
        </div>
      </div>

      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="text-center">Key Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="text-center p-4 bg-muted rounded-lg">
              <p className="text-2xl font-medium">15</p>
              <p className="text-muted-foreground">Total Employees</p>
            </div>
            <div className="text-center p-4 bg-muted rounded-lg">
              <p className="text-2xl font-medium">4</p>
              <p className="text-muted-foreground">Departments</p>
            </div>
          </div>
          <div className="text-center">
            <p className="text-sm text-muted-foreground">
              This organizational chart shows the current reporting structure and team hierarchy.
              All positions are updated as of the current date.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}