import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Users, Building, Crown, User, Mail, Phone } from "lucide-react";

// Mock organizational data with enhanced structure
const orgData = {
  name: "Sarah Wilson",
  role: "Chief Executive Officer",
  email: "sarah.wilson@company.com",
  phone: "+1 (555) 000-0001",
  children: [
    {
      name: "David Chen",
      role: "Chief Technology Officer",
      email: "david.chen@company.com",
      phone: "+1 (555) 000-0002",
      children: [
        {
          name: "John Doe",
          role: "Senior Software Engineer",
          email: "john.doe@company.com",
          phone: "+1 (555) 123-4567",
          children: [
            { 
              name: "Alex Park", 
              role: "Junior Developer",
              email: "alex.park@company.com",
              phone: "+1 (555) 000-0010"
            },
            { 
              name: "Maria Garcia", 
              role: "Frontend Developer",
              email: "maria.garcia@company.com",
              phone: "+1 (555) 000-0011"
            }
          ]
        },
        {
          name: "Lisa Wang",
          role: "DevOps Manager",
          email: "lisa.wang@company.com",
          phone: "+1 (555) 000-0005",
          children: [
            { 
              name: "Tom Brown", 
              role: "Site Reliability Engineer",
              email: "tom.brown@company.com",
              phone: "+1 (555) 000-0012"
            },
            { 
              name: "Ana Silva", 
              role: "Cloud Architect",
              email: "ana.silva@company.com",
              phone: "+1 (555) 000-0013"
            }
          ]
        }
      ]
    },
    {
      name: "Emily Rodriguez",
      role: "Chief Product Officer",
      email: "emily.rodriguez@company.com",
      phone: "+1 (555) 000-0003",
      children: [
        {
          name: "Jane Smith",
          role: "Product Manager",
          email: "jane.smith@company.com",
          phone: "+1 (555) 987-6543",
          children: [
            { 
              name: "Chris Lee", 
              role: "Product Analyst",
              email: "chris.lee@company.com",
              phone: "+1 (555) 000-0014"
            },
            { 
              name: "Sam Johnson", 
              role: "UX Researcher",
              email: "sam.johnson@company.com",
              phone: "+1 (555) 000-0015"
            }
          ]
        },
        {
          name: "Mike Johnson",
          role: "UX Designer",
          email: "mike.johnson@company.com",
          phone: "+1 (555) 456-7890",
          children: [
            { 
              name: "Rachel Kim", 
              role: "Visual Designer",
              email: "rachel.kim@company.com",
              phone: "+1 (555) 000-0016"
            },
            { 
              name: "Kevin Zhang", 
              role: "Interaction Designer",
              email: "kevin.zhang@company.com",
              phone: "+1 (555) 000-0017"
            }
          ]
        }
      ]
    }
  ]
};

interface OrgNodeProps {
  person: any;
  level?: number;
}

function OrgNode({ person, level = 0 }: OrgNodeProps) {
  const hasChildren = person.children && person.children.length > 0;
  const isRoot = level === 0;
  const isExecutive = level === 1;
  const isManager = level === 2;
  
  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getCardStyle = () => {
    if (isRoot) {
      return "bg-gradient-to-br from-purple-100 via-blue-100 to-indigo-100 border-purple-400 shadow-2xl";
    } else if (isExecutive) {
      return "bg-gradient-to-br from-blue-50 via-cyan-50 to-teal-50 border-blue-300 shadow-lg";
    } else if (isManager) {
      return "bg-gradient-to-br from-green-50 via-emerald-50 to-lime-50 border-green-300 shadow-md";
    } else {
      return "bg-gradient-to-br from-gray-50 via-slate-50 to-zinc-50 border-gray-300 shadow-sm";
    }
  };

  const getAvatarStyle = () => {
    if (isRoot) {
      return "bg-gradient-to-r from-purple-600 via-blue-600 to-indigo-600 text-white shadow-xl";
    } else if (isExecutive) {
      return "bg-gradient-to-r from-blue-500 via-cyan-500 to-teal-500 text-white shadow-lg";
    } else if (isManager) {
      return "bg-gradient-to-r from-green-500 via-emerald-500 to-lime-500 text-white shadow-md";
    } else {
      return "bg-gradient-to-r from-gray-400 via-slate-400 to-zinc-400 text-white";
    }
  };

  const getConnectorColor = () => {
    if (isRoot) return "border-purple-400";
    if (isExecutive) return "border-blue-400";
    if (isManager) return "border-green-400";
    return "border-gray-400";
  };
  
  return (
    <div className={`flex flex-col items-center ${level > 0 ? 'mt-8' : ''}`}>
      <Card className={`w-80 ${getCardStyle()} hover:shadow-2xl hover:scale-105 transition-all duration-500 cursor-pointer group`}>
        <CardHeader className="pb-4">
          <div className="flex items-center space-x-4">
            <div className={`w-16 h-16 rounded-full flex items-center justify-center transition-all duration-300 group-hover:scale-110 ${getAvatarStyle()}`}>
              {isRoot ? (
                <Crown className="h-8 w-8" />
              ) : isExecutive ? (
                <Building className="h-7 w-7" />
              ) : (
                <User className="h-6 w-6" />
              )}
            </div>
            <div className="flex-1">
              <CardTitle className="text-lg text-gray-800 group-hover:text-gray-900 transition-colors">
                {person.name}
              </CardTitle>
              <p className="text-sm text-gray-600 font-medium mt-1">{person.role}</p>
              {isRoot && (
                <Badge className="mt-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                  Chief Executive
                </Badge>
              )}
              {isExecutive && (
                <Badge className="mt-2 bg-gradient-to-r from-blue-500 to-cyan-500 text-white">
                  Executive
                </Badge>
              )}
              {isManager && (
                <Badge className="mt-2 bg-gradient-to-r from-green-500 to-emerald-500 text-white">
                  Manager
                </Badge>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-0 space-y-3">
          <div className="flex items-center space-x-3 p-2 rounded-lg bg-white/60 hover:bg-white/80 transition-colors">
            <Mail className="h-4 w-4 text-gray-500" />
            <span className="text-sm text-gray-700 truncate">{person.email}</span>
          </div>
          <div className="flex items-center space-x-3 p-2 rounded-lg bg-white/60 hover:bg-white/80 transition-colors">
            <Phone className="h-4 w-4 text-gray-500" />
            <span className="text-sm text-gray-700">{person.phone}</span>
          </div>
          {hasChildren && (
            <div className="text-center pt-2">
              <Badge variant="outline" className="text-xs">
                {person.children.length} Direct Report{person.children.length !== 1 ? 's' : ''}
              </Badge>
            </div>
          )}
        </CardContent>
      </Card>
      
      {hasChildren && (
        <>
          <div className={`w-0.5 h-8 ${getConnectorColor()} border-l-2 my-2`}></div>
          <div className="relative">
            <div className={`absolute top-0 left-1/2 transform -translate-x-1/2 w-0.5 h-4 ${getConnectorColor()} border-l-2`}></div>
            <div className="flex flex-wrap justify-center gap-12 pt-4">
              {person.children.map((child: any, index: number) => (
                <div key={index} className="flex flex-col items-center relative">
                  {index > 0 && (
                    <div className={`absolute top-4 left-0 w-12 transform -translate-x-full ${getConnectorColor()} border-t-2`}></div>
                  )}
                  {index < person.children.length - 1 && (
                    <div className={`absolute top-4 right-0 w-12 transform translate-x-full ${getConnectorColor()} border-t-2`}></div>
                  )}
                  <div className={`w-0.5 h-4 ${getConnectorColor()} border-l-2 mb-4`}></div>
                  <OrgNode person={child} level={level + 1} />
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

export default function WhatAmI() {
  const totalEmployees = 15;
  const departments = 4;
  const executives = 3;
  const managers = 4;

  return (
    <div className="max-w-[1400px] mx-auto p-6 space-y-8">
      <div className="text-center space-y-4 animate-in fade-in-50 slide-in-from-top duration-700">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-green-500 via-blue-500 to-purple-600 bg-clip-text text-transparent">What Am I?</h1>
        <p className="text-lg text-gray-600">
          Organizational hierarchy and reporting structure
        </p>
      </div>

      {/* Enhanced Key Information */}
      <Card className="max-w-5xl mx-auto animate-in fade-in-50 slide-in-from-bottom duration-700 delay-200 hover:shadow-xl transition-all bg-gradient-to-br from-green-50 to-blue-50 border-green-200 shadow-lg">
        <CardHeader>
          <CardTitle className="text-center text-2xl bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">Organization Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-6 bg-gradient-to-r from-purple-100 to-indigo-100 rounded-xl hover:from-purple-200 hover:to-indigo-200 transition-all duration-300 cursor-pointer shadow-md">
              <Crown className="h-8 w-8 text-purple-700 mx-auto mb-2" />
              <p className="text-2xl font-bold text-purple-700">1</p>
              <p className="text-purple-600 text-sm">CEO</p>
            </div>
            <div className="text-center p-6 bg-gradient-to-r from-blue-100 to-cyan-100 rounded-xl hover:from-blue-200 hover:to-cyan-200 transition-all duration-300 cursor-pointer shadow-md">
              <Building className="h-8 w-8 text-blue-700 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-700">{executives}</p>
              <p className="text-blue-600 text-sm">Executives</p>
            </div>
            <div className="text-center p-6 bg-gradient-to-r from-green-100 to-emerald-100 rounded-xl hover:from-green-200 hover:to-emerald-200 transition-all duration-300 cursor-pointer shadow-md">
              <Users className="h-8 w-8 text-green-700 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-700">{managers}</p>
              <p className="text-green-600 text-sm">Managers</p>
            </div>
            <div className="text-center p-6 bg-gradient-to-r from-orange-100 to-red-100 rounded-xl hover:from-orange-200 hover:to-red-200 transition-all duration-300 cursor-pointer shadow-md">
              <User className="h-8 w-8 text-orange-700 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-700">{totalEmployees}</p>
              <p className="text-orange-600 text-sm">Total Employees</p>
            </div>
          </div>
          <div className="text-center mt-6 p-4">
            <p className="text-gray-600">
              This organizational chart shows the current reporting structure and team hierarchy.
              All positions and contact information are updated as of the current date.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Organizational Chart */}
      <div className="overflow-x-auto animate-in fade-in-50 slide-in-from-bottom duration-700 delay-400">
        <div className="min-w-max flex justify-center py-8">
          <OrgNode person={orgData} />
        </div>
      </div>

      {/* Department Breakdown */}
      <Card className="max-w-4xl mx-auto animate-in fade-in-50 slide-in-from-bottom duration-700 delay-600 hover:shadow-xl transition-all bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200 shadow-lg">
        <CardHeader>
          <CardTitle className="text-center text-2xl bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Department Structure</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 bg-gradient-to-r from-cyan-50 to-blue-50 rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
              <h3 className="text-lg font-bold text-cyan-800 mb-4 flex items-center">
                <Building className="h-5 w-5 mr-2" />
                Technology Department
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Chief Technology Officer:</span>
                  <span className="font-medium text-gray-800">David Chen</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Team Members:</span>
                  <span className="font-medium text-gray-800">6 people</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Focus Areas:</span>
                  <span className="font-medium text-gray-800">Engineering, DevOps</span>
                </div>
              </div>
            </div>
            
            <div className="p-6 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
              <h3 className="text-lg font-bold text-purple-800 mb-4 flex items-center">
                <Users className="h-5 w-5 mr-2" />
                Product Department
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Chief Product Officer:</span>
                  <span className="font-medium text-gray-800">Emily Rodriguez</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Team Members:</span>
                  <span className="font-medium text-gray-800">6 people</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Focus Areas:</span>
                  <span className="font-medium text-gray-800">Product, Design</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}