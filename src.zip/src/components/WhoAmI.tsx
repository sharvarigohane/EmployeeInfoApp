import { useState } from "react";
import { Input } from "./ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Search, User, Briefcase, Building, Loader2, MapPin, Phone, Mail, Calendar, Clock, Shield } from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback } from "./ui/avatar";

// Enhanced mock user data
const userData = {
  "john.doe": {
    name: "John Doe",
    role: "Senior Software Engineer",
    department: "Engineering",
    email: "john.doe@company.com",
    phone: "+1 (555) 123-4567",
    location: "San Francisco, CA",
    joinDate: "January 2021",
    manager: "David Chen",
    team: "Backend Development",
    skills: ["Python", "JavaScript", "Docker", "AWS"],
    projects: ["API Gateway", "User Authentication", "Data Pipeline"],
    workHours: "9:00 AM - 6:00 PM PST",
    status: "Available"
  },
  "jane.smith": {
    name: "Jane Smith",
    role: "Product Manager",
    department: "Product",
    email: "jane.smith@company.com",
    phone: "+1 (555) 987-6543",
    location: "New York, NY",
    joinDate: "March 2020",
    manager: "Emily Rodriguez",
    team: "Core Product",
    skills: ["Product Strategy", "Analytics", "User Research", "Agile"],
    projects: ["Mobile App Redesign", "Feature Prioritization", "User Analytics"],
    workHours: "8:00 AM - 5:00 PM EST",
    status: "In Meeting"
  },
  "mike.johnson": {
    name: "Mike Johnson",
    role: "UX Designer",
    department: "Design",
    email: "mike.johnson@company.com",
    phone: "+1 (555) 456-7890",
    location: "Austin, TX",
    joinDate: "June 2022",
    manager: "Emily Rodriguez",
    team: "Design Systems",
    skills: ["Figma", "Prototyping", "User Testing", "Design Systems"],
    projects: ["Design System Update", "Mobile UX", "Accessibility Audit"],
    workHours: "10:00 AM - 7:00 PM CST",
    status: "Available"
  }
};

const statusColors = {
  "Available": "bg-green-100 text-green-800",
  "In Meeting": "bg-yellow-100 text-yellow-800",
  "Away": "bg-red-100 text-red-800",
  "Do Not Disturb": "bg-purple-100 text-purple-800"
};

export default function WhoAmI() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = async (value: string) => {
    setSearchTerm(value);
    if (value.trim()) {
      setIsLoading(true);
      setHasSearched(true);
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1200));
      const user = userData[value.toLowerCase() as keyof typeof userData];
      setSelectedUser(user || null);
      setIsLoading(false);
    } else {
      setSelectedUser(null);
      setHasSearched(false);
    }
  };

  const clearSearch = () => {
    setSearchTerm("");
    setSelectedUser(null);
    setHasSearched(false);
    setIsLoading(false);
  };

  const tryExample = (example: string) => {
    setSearchTerm(example);
    handleSearch(example);
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-8">
      <div className="text-center space-y-4 animate-in fade-in-50 slide-in-from-top duration-700">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">Who Am I?</h1>
        <p className="text-lg text-gray-600">
          Search for employee information by username or email
        </p>
      </div>

      <div className="space-y-8">
        {/* Enhanced Search Section */}
        <Card className="max-w-2xl mx-auto animate-in fade-in-50 slide-in-from-bottom duration-700 delay-200 bg-white border-gray-200 shadow-lg">
          <CardContent className="p-6 space-y-6">
            <div className="text-center space-y-2">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto">
                <Search className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-800">Employee Search</h3>
              <p className="text-gray-600">Find detailed information about team members</p>
            </div>
            
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-blue-500 h-5 w-5" />
              <Input
                type="text"
                placeholder="Enter username to search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch(searchTerm)}
                className="pl-12 pr-12 h-14 transition-all duration-300 focus:scale-105 border-2 border-purple-200 focus:border-purple-500 rounded-xl bg-white/90 backdrop-blur-sm shadow-lg text-lg"
              />
              {searchTerm && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearSearch}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0 hover:bg-red-100 rounded-full text-red-500"
                >
                  ×
                </Button>
              )}
            </div>

            <div className="flex justify-center">
              <Button 
                onClick={() => handleSearch(searchTerm)}
                disabled={!searchTerm.trim() || isLoading}
                className="px-8 py-3 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-purple-600 hover:to-pink-600 text-white rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Searching...
                  </>
                ) : (
                  <>
                    <Search className="mr-2 h-5 w-5" />
                    Search Employee
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Example Users */}
        {!hasSearched && !isLoading && (
          <Card className="max-w-4xl mx-auto animate-in fade-in-50 slide-in-from-bottom duration-700 delay-400 bg-white border-gray-200 shadow-lg">
            <CardHeader>
              <CardTitle className="text-center text-xl text-gray-800">Try These Example Users</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {["john.doe", "jane.smith", "mike.johnson"].map((example, index) => (
                  <Button
                    key={example}
                    variant="outline"
                    size="lg"
                    onClick={() => tryExample(example)}
                    className={`h-20 flex flex-col items-center justify-center space-y-2 hover:scale-105 transition-all duration-300 border-2 rounded-xl shadow-lg ${
                      index === 0 ? 'border-blue-300 hover:bg-blue-50 hover:border-blue-500' :
                      index === 1 ? 'border-purple-300 hover:bg-purple-50 hover:border-purple-500' :
                      'border-pink-300 hover:bg-pink-50 hover:border-pink-500'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      index === 0 ? 'bg-blue-100' :
                      index === 1 ? 'bg-purple-100' :
                      'bg-pink-100'
                    }`}>
                      <User className={`h-4 w-4 ${
                        index === 0 ? 'text-blue-600' :
                        index === 1 ? 'text-purple-600' :
                        'text-pink-600'
                      }`} />
                    </div>
                    <span className="font-medium">{example}</span>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Loading State */}
        {isLoading && (
          <Card className="max-w-2xl mx-auto animate-in fade-in-50 duration-300 bg-white border-gray-200 shadow-lg">
            <CardContent className="text-center py-12">
              <div className="space-y-4">
                <div className="relative">
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto">
                    <Loader2 className="h-8 w-8 text-white animate-spin" />
                  </div>
                  <div className="absolute inset-0 w-16 h-16 border-4 border-blue-200 rounded-full animate-ping mx-auto"></div>
                </div>
                <div>
                  <p className="text-lg font-medium text-gray-800">Searching Employee Database</p>
                  <p className="text-gray-600">Finding detailed profile information...</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Enhanced User Profile */}
        {selectedUser && !isLoading && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-in fade-in-50 slide-in-from-bottom duration-700">
            {/* Profile Overview */}
            <Card className="lg:col-span-1 bg-white border-gray-200 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardHeader className="text-center pb-4">
                <div className="relative mx-auto mb-4">
                  <Avatar className="w-24 h-24 border-4 border-white shadow-lg">
                    <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-600 text-white text-2xl font-bold">
                      {getInitials(selectedUser.name)}
                    </AvatarFallback>
                  </Avatar>
                  <Badge 
                    className={`absolute -bottom-2 -right-2 ${statusColors[selectedUser.status as keyof typeof statusColors] || 'bg-gray-100 text-gray-800'}`}
                  >
                    {selectedUser.status}
                  </Badge>
                </div>
                <CardTitle className="text-2xl bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
                  {selectedUser.name}
                </CardTitle>
                <p className="text-gray-600 font-medium">{selectedUser.role}</p>
                <Badge variant="secondary" className="bg-gradient-to-r from-blue-100 to-purple-100 text-blue-800">
                  {selectedUser.department}
                </Badge>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center space-x-3 p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition-all duration-300">
                    <Mail className="h-5 w-5 text-blue-600" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-800">Email</p>
                      <p className="text-sm text-gray-600 truncate">{selectedUser.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition-all duration-300">
                    <Phone className="h-5 w-5 text-green-600" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-800">Phone</p>
                      <p className="text-sm text-gray-600">{selectedUser.phone}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition-all duration-300">
                    <MapPin className="h-5 w-5 text-purple-600" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-800">Location</p>
                      <p className="text-sm text-gray-600">{selectedUser.location}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Professional Details */}
            <Card className="lg:col-span-2 bg-white border-gray-200 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardHeader>
                <CardTitle className="text-xl text-gray-800">
                  Professional Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-lg bg-blue-50 hover:bg-blue-100 transition-all duration-300 border border-blue-200">
                    <div className="flex items-center space-x-2 mb-2">
                      <Briefcase className="h-5 w-5 text-blue-600" />
                      <p className="font-medium text-gray-800">Team</p>
                    </div>
                    <p className="text-gray-600">{selectedUser.team}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-green-50 hover:bg-green-100 transition-all duration-300 border border-green-200">
                    <div className="flex items-center space-x-2 mb-2">
                      <User className="h-5 w-5 text-green-600" />
                      <p className="font-medium text-gray-800">Reports To</p>
                    </div>
                    <p className="text-gray-600">{selectedUser.manager}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-purple-50 hover:bg-purple-100 transition-all duration-300 border border-purple-200">
                    <div className="flex items-center space-x-2 mb-2">
                      <Calendar className="h-5 w-5 text-purple-600" />
                      <p className="font-medium text-gray-800">Join Date</p>
                    </div>
                    <p className="text-gray-600">{selectedUser.joinDate}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-orange-50 hover:bg-orange-100 transition-all duration-300 border border-orange-200">
                    <div className="flex items-center space-x-2 mb-2">
                      <Clock className="h-5 w-5 text-orange-600" />
                      <p className="font-medium text-gray-800">Work Hours</p>
                    </div>
                    <p className="text-gray-600">{selectedUser.workHours}</p>
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="p-5 rounded-lg bg-gray-50 hover:bg-gray-100 transition-all duration-300 border border-gray-200">
                    <h4 className="font-medium text-gray-800 mb-4 flex items-center text-lg">
                      <Shield className="h-5 w-5 text-blue-600 mr-2" />
                      Skills & Expertise
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedUser.skills.map((skill: string, index: number) => (
                        <Badge 
                          key={skill} 
                          variant="secondary" 
                          className={`px-3 py-1 ${
                            index % 4 === 0 ? 'bg-blue-100 text-blue-800 hover:bg-blue-200' :
                            index % 4 === 1 ? 'bg-green-100 text-green-800 hover:bg-green-200' :
                            index % 4 === 2 ? 'bg-purple-100 text-purple-800 hover:bg-purple-200' :
                            'bg-orange-100 text-orange-800 hover:bg-orange-200'
                          }`}
                        >
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="p-5 rounded-lg bg-blue-50 hover:bg-blue-100 transition-all duration-300 border border-blue-200">
                    <h4 className="font-medium text-gray-800 mb-4 flex items-center text-lg">
                      <Building className="h-5 w-5 text-blue-600 mr-2" />
                      Current Projects
                    </h4>
                    <div className="space-y-3">
                      {selectedUser.projects.map((project: string, index: number) => (
                        <div 
                          key={project} 
                          className="p-3 rounded-lg bg-white shadow-sm border-l-4 border-blue-400 hover:shadow-md transition-all duration-200"
                        >
                          <p className="text-gray-700 font-medium">{project}</p>
                          <p className="text-xs text-gray-500 mt-1">Active Project</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* No Results */}
        {hasSearched && !selectedUser && !isLoading && (
          <Card className="max-w-2xl mx-auto animate-in fade-in-50 slide-in-from-bottom duration-500 bg-white border-gray-200 shadow-lg">
            <CardContent className="text-center py-12 space-y-4">
              <div className="w-16 h-16 bg-gradient-to-r from-gray-400 to-gray-500 rounded-full flex items-center justify-center mx-auto">
                <User className="h-8 w-8 text-white" />
              </div>
              <div>
                <p className="text-lg font-medium text-gray-800 mb-2">Employee Not Found</p>
                <p className="text-gray-600 mb-4">
                  No user found with that username. Try one of these available users:
                </p>
                <div className="flex flex-wrap justify-center gap-3">
                  {["john.doe", "jane.smith", "mike.johnson"].map((example, index) => (
                    <Button
                      key={example}
                      variant="outline"
                      size="sm"
                      onClick={() => tryExample(example)}
                      className={`hover:scale-105 transition-all duration-200 border-2 rounded-lg ${
                        index === 0 ? 'border-blue-300 hover:bg-blue-50 text-blue-700' :
                        index === 1 ? 'border-purple-300 hover:bg-purple-50 text-purple-700' :
                        'border-pink-300 hover:bg-pink-50 text-pink-700'
                      }`}
                    >
                      {example}
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}