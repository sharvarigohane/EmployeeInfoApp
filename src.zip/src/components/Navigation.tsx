import { Button } from "./ui/button";
import { Home } from "lucide-react";

interface NavigationProps {
  selectedOption: string | null;
  onOptionSelect: (option: string | null) => void;
}

export default function Navigation({ selectedOption, onOptionSelect }: NavigationProps) {
  const options = [
    { id: 'who-am-i', label: 'Who Am I?' },
    { id: 'what-am-i', label: 'What Am I?' },
    { id: 'tools', label: 'Tools' }
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-xl supports-[backdrop-filter]:bg-white/70 border-b border-purple-200/50 z-50 animate-in slide-in-from-top duration-500 shadow-lg shadow-purple-500/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          {/* Home Button */}
          <Button
            variant="ghost"
            onClick={() => onOptionSelect(null)}
            className="rounded-xl transition-all duration-300 hover:scale-105 hover:bg-gradient-to-r hover:from-purple-50 hover:to-blue-50 hover:text-purple-700"
          >
            <Home className="h-5 w-5 mr-2" />
            Home
          </Button>

          {/* Navigation Options */}
          <div className="flex space-x-2">
            {options.map((option, index) => (
              <Button
                key={option.id}
                variant={selectedOption === option.id ? "default" : "ghost"}
                onClick={() => onOptionSelect(option.id)}
                className={`rounded-xl transition-all duration-300 hover:scale-105 animate-in fade-in-50 slide-in-from-top delay-100 ${
                  selectedOption === option.id 
                    ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg shadow-purple-500/30' 
                    : 'hover:bg-gradient-to-r hover:from-purple-50 hover:to-blue-50 hover:text-purple-700'
                }`}
                style={{ animationDelay: `${index * 100 + 200}ms` }}
              >
                {option.label}
              </Button>
            ))}
          </div>

          {/* Spacer for balance */}
          <div className="w-20"></div>
        </div>
      </div>
    </nav>
  );
}