import { useState } from "react";
import { Input } from "./ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Search, User, Briefcase, Building } from "lucide-react";

// Mock user data
const userData = {
  "john.doe": {
    name: "John Doe",
    role: "Senior Software Engineer",
    department: "Engineering",
    email: "john.doe@company.com",
    phone: "+1 (555) 123-4567",
    location: "San Francisco, CA"
  },
  "jane.smith": {
    name: "Jane Smith",
    role: "Product Manager",
    department: "Product",
    email: "jane.smith@company.com",
    phone: "+1 (555) 987-6543",
    location: "New York, NY"
  },
  "mike.johnson": {
    name: "Mike Johnson",
    role: "UX Designer",
    department: "Design",
    email: "mike.johnson@company.com",
    phone: "+1 (555) 456-7890",
    location: "Austin, TX"
  }
};

export default function WhoAmI() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedUser, setSelectedUser] = useState<any>(null);

  const handleSearch = (value: string) => {
    setSearchTerm(value);
    const user = userData[value.toLowerCase() as keyof typeof userData];
    setSelectedUser(user || null);
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="text-center space-y-4">
        <h1 className="text-3xl font-medium">Who Am I?</h1>
        <p className="text-muted-foreground">
          Search for employee information by username or email
        </p>
      </div>

      <div className="relative max-w-md mx-auto">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
        <Input
          type="text"
          placeholder="Enter username (try: john.doe, jane.smith, mike.johnson)"
          value={searchTerm}
          onChange={(e) => handleSearch(e.target.value)}
          className="pl-10"
        />
      </div>

      {selectedUser && (
        <Card className="max-w-2xl mx-auto">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <User className="h-8 w-8 text-primary" />
            </div>
            <CardTitle className="text-2xl">{selectedUser.name}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center space-x-3">
                <Briefcase className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">Role</p>
                  <p className="text-muted-foreground">{selectedUser.role}</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Building className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">Department</p>
                  <p className="text-muted-foreground">{selectedUser.department}</p>
                </div>
              </div>
            </div>
            <div className="space-y-3 pt-4 border-t">
              <div>
                <p className="font-medium">Email</p>
                <p className="text-muted-foreground">{selectedUser.email}</p>
              </div>
              <div>
                <p className="font-medium">Phone</p>
                <p className="text-muted-foreground">{selectedUser.phone}</p>
              </div>
              <div>
                <p className="font-medium">Location</p>
                <p className="text-muted-foreground">{selectedUser.location}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {searchTerm && !selectedUser && (
        <Card className="max-w-2xl mx-auto">
          <CardContent className="text-center py-8">
            <p className="text-muted-foreground">No user found with that username.</p>
            <p className="text-sm text-muted-foreground mt-2">
              Try: john.doe, jane.smith, or mike.johnson
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}