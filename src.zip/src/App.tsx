import { useState } from "react";
import { Button } from "./components/ui/button";
import Navigation from "./components/Navigation";
import WhoAmI from "./components/WhoAmI";
import WhatAmI from "./components/WhatAmI";
import Tools from "./components/Tools";
import { User, Users, Wrench } from "lucide-react";

export default function App() {
  const [selectedOption, setSelectedOption] = useState<string | null>(null);

  const handleOptionSelect = (option: string | null) => {
    setSelectedOption(option);
  };

  const renderContent = () => {
    switch (selectedOption) {
      case 'who-am-i':
        return <WhoAmI />;
      case 'what-am-i':
        return <WhatAmI />;
      case 'tools':
        return <Tools />;
      default:
        return null;
    }
  };

  // Initial landing screen with three central options
  if (!selectedOption) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#667eea] via-[#764ba2] to-[#f093fb] flex items-center justify-center p-6 relative overflow-hidden">
        {/* Animated background orbs */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-gradient-to-r from-pink-400 to-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse"></div>
          <div className="absolute top-3/4 right-1/4 w-64 h-64 bg-gradient-to-r from-yellow-400 to-red-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse animation-delay-2000"></div>
          <div className="absolute bottom-1/4 left-1/2 w-64 h-64 bg-gradient-to-r from-blue-400 to-cyan-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse animation-delay-4000"></div>
        </div>
        
        <div className="text-center space-y-8 max-w-2xl mx-auto relative z-10">
          <div className="space-y-4 animate-in fade-in-50 duration-700">
            <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-white via-white to-white/80 bg-clip-text text-transparent drop-shadow-2xl">
              Welcome
            </h1>
            <p className="text-lg text-white/90 drop-shadow-lg">
              Choose an option below to get started
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
            <Button
              variant="outline"
              size="lg"
              onClick={() => handleOptionSelect('who-am-i')}
              className="group h-32 flex flex-col items-center justify-center space-y-4 bg-white/90 backdrop-blur-sm border-white/20 hover:bg-white hover:scale-110 hover:shadow-2xl transition-all duration-500 animate-in fade-in-50 slide-in-from-bottom-4 delay-100 text-gray-800"
            >
              <div className="p-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl group-hover:from-purple-600 group-hover:to-pink-600 transition-all duration-300">
                <User className="h-8 w-8 text-white group-hover:scale-110 transition-transform duration-300" />
              </div>
              <span className="text-lg font-medium">Who Am I?</span>
            </Button>
            
            <Button
              variant="outline"
              size="lg"
              onClick={() => handleOptionSelect('what-am-i')}
              className="group h-32 flex flex-col items-center justify-center space-y-4 bg-white/90 backdrop-blur-sm border-white/20 hover:bg-white hover:scale-110 hover:shadow-2xl transition-all duration-500 animate-in fade-in-50 slide-in-from-bottom-4 delay-200 text-gray-800"
            >
              <div className="p-3 bg-gradient-to-r from-green-500 to-blue-600 rounded-xl group-hover:from-blue-600 group-hover:to-cyan-600 transition-all duration-300">
                <Users className="h-8 w-8 text-white group-hover:scale-110 transition-transform duration-300" />
              </div>
              <span className="text-lg font-medium">What Am I?</span>
            </Button>
            
            <Button
              variant="outline"
              size="lg"
              onClick={() => handleOptionSelect('tools')}
              className="group h-32 flex flex-col items-center justify-center space-y-4 bg-white/90 backdrop-blur-sm border-white/20 hover:bg-white hover:scale-110 hover:shadow-2xl transition-all duration-500 animate-in fade-in-50 slide-in-from-bottom-4 delay-300 text-gray-800"
            >
              <div className="p-3 bg-gradient-to-r from-orange-500 to-red-600 rounded-xl group-hover:from-red-600 group-hover:to-pink-600 transition-all duration-300">
                <Wrench className="h-8 w-8 text-white group-hover:scale-110 transition-transform duration-300" />
              </div>
              <span className="text-lg font-medium">Tools</span>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Main app with navigation and content
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <Navigation 
        selectedOption={selectedOption} 
        onOptionSelect={handleOptionSelect} 
      />
      <main className="pt-20">
        {renderContent()}
      </main>
    </div>
  );
}